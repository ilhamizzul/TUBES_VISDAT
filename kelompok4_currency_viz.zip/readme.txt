LINK colab : https://colab.research.google.com/drive/18MZtbv3e05692m5AECU_OPtHyf11QNTA?usp=sharing#scrollTo=d8fusaTR0HFy
LINK webapp : https://region-currency-value.herokuapp.com/myapp